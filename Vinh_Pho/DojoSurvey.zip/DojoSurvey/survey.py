from flask import Flask, render_template, request
app= Flask(__name__)
@app.route('/')
def survey():
    return render_template('index.html')
@app.route('/result',methods=['POST'])
def getinfo():
    iname=request.form['name']
    ilocation=request.form['location']
    iflang=request.form['language']
    icomment=request.form['comment']
#@app.route('/result')
#def result():
    return render_template('result.html',iname=iname,ilocation=ilocation,iflang=iflang,icomment=icomment)
   
    
app.run(debug=True)